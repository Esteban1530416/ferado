ALTER TABLE `#__sunfw_styles` ADD `social_share_data` LONGTEXT DEFAULT NULL AFTER `cookie_law_data`;
