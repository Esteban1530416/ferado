ALTER TABLE `#__sunfw_styles` ADD `commenting_data` LONGTEXT DEFAULT NULL AFTER `social_share_data`;
